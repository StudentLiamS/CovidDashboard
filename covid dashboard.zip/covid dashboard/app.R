library(shiny)
library(ggplot2)
library(DT)
mobility <- read.csv("full_grouped.csv",)
mobility$WHO_Region <- as.factor(mobility$WHO_Region) # returns object of a class.
mobility$Date <- as.Date(mobility$Date, format = "%m/%d/%Y")
# Define UI for application of the Covid dashboard
ui <- fluidPage(
  titlePanel("COVID-19 Dashboard"),
  sidebarLayout(
    sidebarPanel(
      selectInput(inputId = "dv",label = "Category",

                  choices = c("Confirmed","Deaths","Recovered","Active","New_cases","New_deaths","New_recovered"),
                              selected = "WHO_Region"),
      em("Select a category you wish to see as the Y axis of the scatter graph"),

      selectInput(inputId = "WHO_Region",label = "WHO_Region",
                  choices = levels(mobility$WHO_Region),
                  multiple = TRUE,
                  selected = ("Europe"),
                  ),
      em("Select the Regions you wish to see plotted on the graph"),
      dateRangeInput(inputId = "date", label = "Date range",
                     start = min(mobility$Date),
                     end = max(mobility$Date)),
      em("Select the date for the plotted data to be between."),
    ),
    mainPanel(
      img(src = "Uni.png", height = 100, width = 100, align = "right"),
      titlePanel(
        h1("Covid-19 Scatter graph",align = "center"),
        ),
      em("The scatter graph of the selected data from the user"), align = "center",
      plotOutput(outputId = "plot"),
      h2("Data table"),
      em("Data table from the data set that was imported"),br(),a("Dataset",href = "https://www.kaggle.com/datasets/imdevskp/corona-virus-report"),
      DT:: dataTableOutput(outputId = "table"),
      em("The table shows the integer value of data collected in each category  of data")
    )
  )
)

# Define server logic required to draw a the scatter graph
server <- function(input, output) {
  filtered_data <- reactive({
    subset(mobility,
           WHO_Region %in% input$WHO_Region &
             Date >= input$date[1] & Date <= input$date[2])

  })
  output$plot <- renderPlot({
    ggplot(filtered_data(),
           aes_string(x="Date", y= input$dv, color="WHO_Region")) + geom_point(alpha = 0.5) +
      ylab("The integer  value for the selected input.")
  })

  output$table <- DT:: renderDataTable({
    filtered_data()
  })
}

# Run the application
shinyApp(ui = ui, server = server)
