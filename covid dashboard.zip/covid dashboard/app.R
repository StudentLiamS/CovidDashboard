#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(ggplot2)
library(DT)
mobility <- read.csv("full_grouped.csv",)
mobility$WHO_Region <- as.factor(mobility$WHO_Region) # returns object of a class.
mobility$Date <- as.Date(mobility$Date, format = "%m/%d/%Y")
# Define UI for application that will show a simple project
ui <- fluidPage(
  titlePanel("COVID-19 Dashboard"),
  sidebarLayout(
    sidebarPanel(
      selectInput(inputId = "dv",label = "Category",
                  choices = c("Confirmed","Deaths","Recovered","Active","New_cases","New_deaths","New_recovered"),
                              selected = "WHO_Region"),

      selectInput(inputId = "WHO_Region",label = "WHO_Region",
                  choices = levels(mobility$WHO_Region),
                  multiple = TRUE,
                  selected = ("Europe"),
                  ),
      dateRangeInput(inputId = "date", label = "date range",
                     start = min(mobility$Date),
                     end = max(mobility$Date))

    ),
    mainPanel(
      plotOutput(outputId = "plot"),
      DT:: dataTableOutput(outputId = "table"),
      em("The postive and negative percentages indicates the chnage in value compared to the baseline")
    )
  )
)

# Define server logic required to draw a
server <- function(input, output) {
  filtered_data <- reactive({
    subset(mobility,
           WHO_Region %in% input$WHO_Region &
             Date >= input$date[1] & Date <= input$date[2])
  })
  output$plot <- renderPlot({
    ggplot(filtered_data(),
           aes_string(x="Date", y= input$dv, color="WHO_Region")) + geom_point(alpha = 0.5) +
      ylab("%change from basline")
  })

  output$table <- DT:: renderDataTable({
    filtered_data()
  })
}

# Run the application
shinyApp(ui = ui, server = server)
